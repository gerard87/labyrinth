int** generateMaze(int rows, int cols);    
void printMaze(int** maze, int rows, int cols);
